package com.onlinebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
